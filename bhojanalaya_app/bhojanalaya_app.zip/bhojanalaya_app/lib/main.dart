import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Bhojanalaya',
      theme: ThemeData.dark().copyWith(
        visualDensity: VisualDensity.adaptivePlatformDensity,
        // This makes the visual density adapt to the platform that you run
        // the app on. For desktop platforms, the controls will be smaller and
        // closer together (more dense) than on mobile platforms.
        primaryColor: Colors.red[800],
        scaffoldBackgroundColor: Color(0xFF000000),
      ),
      home: MyHomePage(title: 'Bhojanalaya'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    // This method is rerun every time setState is called, for instance as done
    // by the _incrementCounter method above.
    return SafeArea(
      child: MaterialApp(
        color: Colors.yellow,
        home: DefaultTabController(
          length: 4,
          child: new Scaffold(
            body: TabBarView(
              children: [
                new Container(
                  color: Colors.yellowAccent[200],
                  // CustomScrollView(
                  //     slivers: <Widget>[
                  //       // Add the app bar to the CustomScrollView.
                  //       SliverAppBar(
                  //         //Image.asset('asset/images/restaurant.jpg'),
                  //         // Provide a standard title.
                  //         title: Text(
                  //           'Bhojanalaya',
                  //           style: TextStyle(
                  //             fontFamily: 'Raleway',
                  //             fontSize: 40.0,
                  //             letterSpacing: 2.5,
                  //             fontWeight: FontWeight.bold,
                  //           ),
                  //         ),
                  //         // Allows the user to reveal the app bar if they begin scrolling
                  //         // back up the list of items.
                  //         floating: true,
                  //         // Make the initial height of the SliverAppBar larger than normal.
                  //         expandedHeight: 200,
                  //         centerTitle: true,
                  //       ),
                  //       // Next, create a SliverList
                  //       SliverList(
                  //         // Use a delegate to build items as they're scrolled on screen.
                  //         delegate: SliverChildBuilderDelegate(
                  //           // The builder function returns a ListTile with a title that
                  //           // displays the index of the current item.
                  //           (context, index) =>
                  //               ListTile(title: Text('Item #$index')),
                  //           // Builds 1000 ListTiles
                  //           childCount: 1000,
                  //         ),
                  //       ),
                  //     ],
                  //   ),
                ),
                new Container(
                  color: Colors.orangeAccent[200],
                ),
                new Container(
                  color: Colors.lightGreen,
                ),
                new Container(
                  color: Colors.cyan[200],
                ),
              ],
            ),
            appBar: new TabBar(
              tabs: [
                Tab(
                  icon: new Icon(Icons.home),
                ),
                Tab(
                  icon: new Icon(Icons.rss_feed),
                ),
                Tab(
                  icon: new Icon(Icons.perm_identity),
                ),
                Tab(
                  icon: new Icon(Icons.settings),
                )
              ],
              labelColor: Colors.yellow,
              unselectedLabelColor: Colors.blue,
              indicatorSize: TabBarIndicatorSize.label,
              indicatorPadding: EdgeInsets.all(5.0),
              indicatorColor: Colors.white,
            ),
            backgroundColor: Colors.black,
          ),
        ),
      ),
    );

    return Scaffold(
      body: CustomScrollView(
        slivers: <Widget>[
          // Add the app bar to the CustomScrollView.
          SliverAppBar(
            //Image.asset('asset/images/restaurant.jpg'),
            // Provide a standard title.
            title: Text(
              'Bhojanalaya',
              style: TextStyle(
                fontFamily: 'Raleway',
                fontSize: 40.0,
                letterSpacing: 2.5,
                fontWeight: FontWeight.bold,
              ),
            ),
            // Allows the user to reveal the app bar if they begin scrolling
            // back up the list of items.
            floating: true,
            // Make the initial height of the SliverAppBar larger than normal.
            expandedHeight: 200,
            centerTitle: true,
          ),
          // Next, create a SliverList
          SliverList(
            // Use a delegate to build items as they're scrolled on screen.
            delegate: SliverChildBuilderDelegate(
              // The builder function returns a ListTile with a title that
              // displays the index of the current item.
              (context, index) => ListTile(title: Text('Item #$index')),
              // Builds 1000 ListTiles
              childCount: 1000,
            ),
          ),
        ],
      ),
    );
  }
}
